# app/streamlit_chatbot.py
import os
import streamlit as st
import faiss
import numpy as np
import ast, pandas as pd
from dotenv import load_dotenv
from sentence_transformers import SentenceTransformer
from app.config.config import DB_FAISS_PATH
from app.components.llm import groq_load_llm
from app.common.logger import get_logger
from app.evaluation.metrics import evaluate_response


# Explicitly load your intended .env file and override any existing key
dotenv_path = r"E:\Anubavam_task\24Oct\.env"
load_dotenv(dotenv_path=dotenv_path, override=True)

# Force set the key
GROQ_API_KEY = os.getenv("GROQ_API_KEY")
os.environ["GROQ_API_KEY"] = GROQ_API_KEY
print("✅ Using GROQ_API_KEY:", GROQ_API_KEY[:6], "******") 


# -----------------------------
# Initialize logger
# -----------------------------
logger = get_logger(__name__)
logger.info("🚀 Starting Streamlit chatbot...")

# -----------------------------
# Load environment variables
# -----------------------------
dotenv_path = os.path.join(os.path.dirname(__file__), ".env")
load_dotenv(dotenv_path=dotenv_path)

# GROQ API Key
GROQ_API_KEY = os.getenv("GROQ_API_KEY")
if not GROQ_API_KEY:
    st.error("❌ GROQ_API_KEY not found. Please check your .env file.")
    logger.error("❌ GROQ_API_KEY not found. Check your .env file.")
    st.stop()

os.environ["GROQ_API_KEY"] = GROQ_API_KEY
logger.info(f"✅ GROQ_API_KEY loaded (first 6 chars): {GROQ_API_KEY[:6]}******")
st.success("✅ GROQ_API_KEY loaded successfully.")


# -----------------------------
# Query classification and keyword ranking
# -----------------------------

faq_df = pd.read_csv(r"E:\Anubavam_task\24Oct\data\faq_knowledge_base.csv")
faq_df.head()

# Convert stringified keywords to actual lists
faq_df['keywords'] = faq_df['keywords'].apply(ast.literal_eval)

def classify_query(user_input: str) -> str:
    """Classify user query into a category using FAQ keywords."""
    user_input = user_input.lower()
    for _, row in faq_df.iterrows():
        for kw in row['keywords']:
            if kw.lower() in user_input:
                return row['category']
    return "General"

def rank_docs_by_keywords(user_input: str, docs: list) -> list:
    """Rank retrieved docs by number of keyword matches."""
    user_tokens = set(user_input.lower().split())
    scored_docs = []
    for d in docs:
        kw_set = set([k.lower() for k in d.get("keywords", [])])
        score = len(user_tokens & kw_set)
        scored_docs.append((score, d))
    scored_docs.sort(reverse=True, key=lambda x: x[0])
    return [d for score, d in scored_docs if score > 0]

# -----------------------------
# Load FAISS index and metadata
# -----------------------------
try:
    index = faiss.read_index(f"{DB_FAISS_PATH}.index")
    metadata = np.load(f"{DB_FAISS_PATH}_metadata.npy", allow_pickle=True).tolist()
    logger.info(f"✅ FAISS database loaded from {DB_FAISS_PATH}")
except Exception as e:
    st.error(f"❌ Failed to load FAISS database: {e}")
    logger.exception("❌ Failed to load FAISS database.")
    st.stop()

# -----------------------------
# Load embedding model
# -----------------------------
try:
    embedding_model = SentenceTransformer("all-MiniLM-L6-v2")
    logger.info("✅ Embedding model loaded successfully.")
except Exception as e:
    st.error(f"❌ Failed to load embedding model: {e}")
    logger.exception("❌ Failed to load embedding model.")
    st.stop()

# -----------------------------
# Initialize LLM once (no session memory)
# -----------------------------
llm = groq_load_llm(model_name="llama-3.1-8b-instant", groq_api_key=GROQ_API_KEY)
if not llm:
    st.error("❌ Failed to load Groq LLM. Chatbot will only use raw data retrieval.")
    logger.error("❌ LLM initialization returned None.")
else:
    logger.info("✅ LLM loaded successfully.")

# -----------------------------
# Streamlit UI
# -----------------------------
st.set_page_config(page_title="🛍️ Customer Support Chatbot", layout="centered")
st.title("🛍️ Customer Support Assistant")
st.write("Hi there! I'm your virtual assistant. Ask me anything about your orders, shipping, products, or policies.")

# -----------------------------
# Session state for chat history
# -----------------------------
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

# -----------------------------
# Retrieve top-k relevant documents from FAISS
# -----------------------------
def retrieve_relevant_docs(query: str, top_k: int = 3):
    try:
        query_vector = embedding_model.encode([query], convert_to_numpy=True, normalize_embeddings=True)
        distances, indices = index.search(query_vector, k=top_k)
        results = [metadata[i] for i in indices[0] if i < len(metadata)]
        return results
    except Exception as e:
        logger.exception("Error retrieving vectors")
        return []



# -----------------------------
# Generate human-like response
# -----------------------------
def generate_response(user_input: str) -> str:
    logger.info(f"🧠 User input: {user_input}")

    # -----------------------------
    # Retrieve relevant documents
    # -----------------------------
    relevant_docs = retrieve_relevant_docs(user_input, top_k=2)
    retrieved_info = "\n".join([f"- {doc.get('answer') or doc.get('content')}" for doc in relevant_docs if doc])

    if not retrieved_info:
        retrieved_info = "No matching FAQ found."

    logger.info(f"📄 Retrieved info from FAISS:\n{retrieved_info}")

    # -----------------------------
    # Prepare prompt for LLM
    # -----------------------------
    context = "\n".join([f"User: {c['user']}\nBot: {c['bot']}" for c in st.session_state.chat_history[-3:]])

    prompt = f"""
You are a friendly, human-like customer support assistant.
Respond naturally using simple language, not robotic.

Relevant Info from Documents:
{retrieved_info}

Recent Conversation:
{context}

User: {user_input}
Bot:
"""

    if not llm:
        logger.warning("❌ LLM not loaded. Returning retrieved info only.")
        return retrieved_info

    try:
        logger.info("🚀 Sending prompt to Groq...")
        response = llm.invoke(prompt)

        # Extract text from response
        if hasattr(response, "content"):
            response_text = response.content
        elif isinstance(response, str):
            response_text = response
        else:
            response_text = str(response)

        logger.info(f"✅ LLM Response: {response_text[:200]}")

                # -----------------------------
        # Validation: highlight which parts come from documents
        # -----------------------------
        validation_info = ""
        if retrieved_info != "No matching FAQ found.":
            validation_info = f"\n\n---\nNote: The following info was retrieved from your documents:\n{retrieved_info}"

        # -----------------------------
        # Evaluate response vs reference (if available)
        # -----------------------------
        eval_metrics = None
        if relevant_docs and relevant_docs[0].get("answer"):
            reference_answer = relevant_docs[0]["answer"]
            eval_metrics = evaluate_response(response_text, reference_answer)
            logger.info(f"📊 Evaluation: {eval_metrics}")
            validation_info += f"\n\n**Evaluation Metrics:** {eval_metrics}"

        # Return final combined output
        return response_text.strip() + validation_info
        

    except Exception as e:
        logger.exception(f"❌ LLM error: {e}")
        return f"Sorry, something went wrong while generating a response: {e}"


# -----------------------------
# Chat input area
# -----------------------------
user_input = st.chat_input("Type your message...")

if user_input:
    logger.info("Entering generate_response()")
    bot_response = generate_response(user_input)
    st.session_state.chat_history.append({"user": user_input, "bot": bot_response})

# -----------------------------
# Display chat history
# -----------------------------
for chat in st.session_state.chat_history:
    with st.chat_message("user"):
        st.markdown(f"**You:** {chat['user']}")
    with st.chat_message("assistant"):
        # Split bot message to separate response and metadata (if any)
        if "---" in chat['bot']:
            response_text, metadata_text = chat['bot'].split("---", 1)
            st.markdown(response_text.strip())
            st.markdown("**📄 Retrieved Info / Metadata:**")
            st.markdown(metadata_text.strip())
        else:
            st.markdown(chat['bot'])