# test_chatbot.py
from sentence_transformers import SentenceTransformer
import faiss
import numpy as np
from app.config.config import DB_FAISS_PATH

# ------------------------
# Load FAISS index and metadata
# ------------------------
index = faiss.read_index(DB_FAISS_PATH + ".index")
metadata = np.load(DB_FAISS_PATH + "_metadata.npy", allow_pickle=True).tolist()

# Load embedding model
model = SentenceTransformer("all-MiniLM-L6-v2")

def get_answer(query, top_k=3):
    # Convert query to embedding
    query_vector = model.encode([query], convert_to_numpy=True, normalize_embeddings=True)
    
    # Search top K results
    distances, indices = index.search(query_vector, top_k)

    results = []
    for idx, dist in zip(indices[0], distances[0]):
        doc_meta = metadata[idx]
        source = doc_meta.get("source", "unknown")
        answer = doc_meta.get("answer") or doc_meta.get("content") or "No text available."

        results.append({
            "source": source,
            "distance": dist,
            "answer": answer
        })
    return results

# ------------------------
# Chat loop
# ------------------------
if __name__ == "__main__":
    print("Chatbot ready! Type 'exit' to quit.")
    while True:
        query = input("\nAsk your question: ")
        if query.lower() == "exit":
            break

        top_results = get_answer(query)
        print("\n🔍 Top Results:\n")
        for i, res in enumerate(top_results, start=1):
            print(f"Result {i}:")
            print(f"Source: {res['source']}")
            print(f"Distance: {res['distance']:.4f}")
            print(f"Answer: {res['answer']}\n")
