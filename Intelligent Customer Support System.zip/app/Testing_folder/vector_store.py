# app/components/vector_store.py
import os
import faiss
import numpy as np
from app.components.embeddings import get_embedding_model
from app.components.custom_document import Document
from app.common.logger import get_logger
from app.common.custom_exception import CustomException
from app.config.config import DB_FAISS_PATH

logger = get_logger(__name__)

# Save vector store
def save_vector_store(documents):
    try:
        if not documents:
            raise CustomException("No documents to index")

        embedding_model = get_embedding_model()
        logger.info("Generating embeddings for vector store...")

        texts = [doc.page_content for doc in documents]
        embeddings = embedding_model.encode(texts, convert_to_numpy=True)

        dim = embeddings.shape[1]
        index = faiss.IndexFlatL2(dim)
        index.add(embeddings)

        # Ensure folder exists
        os.makedirs(os.path.dirname(DB_FAISS_PATH), exist_ok=True)

        # Save index and metadata
        faiss.write_index(index, DB_FAISS_PATH + ".index")
        metadata = [doc.metadata for doc in documents]
        np.save(DB_FAISS_PATH + "_metadata.npy", metadata, allow_pickle=True)

        logger.info(f"Vector store saved successfully at {DB_FAISS_PATH}")
        return index, metadata

    except Exception as e:
        error_message = CustomException("Failed to create vector store", e)
        logger.error(str(error_message))
        raise error_message


# Load vector store
def load_vector_store():
    try:
        if not os.path.exists(DB_FAISS_PATH + ".index") or not os.path.exists(DB_FAISS_PATH + "_metadata.npy"):
            logger.warning("Vector store not found.")
            return None, None

        index = faiss.read_index(DB_FAISS_PATH + ".index")
        metadata = np.load(DB_FAISS_PATH + "_metadata.npy", allow_pickle=True).tolist()
        logger.info("Vector store loaded successfully.")
        return index, metadata

    except Exception as e:
        error_message = CustomException("Failed to load vector store", e)
        logger.error(str(error_message))
        return None, None
