# app/process_csv_folder.py
import os
import pandas as pd
from app.components.vector_store import save_vector_store
from app.components.custom_document import Document
from app.common.logger import get_logger
from app.common.custom_exception import CustomException

logger = get_logger(__name__)

import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))


DATA_FOLDER = r"E:\Anubavam_task\OCt22\data"  # your CSV folder

def load_csv_files():
    all_docs = []
    for file in os.listdir(DATA_FOLDER):
        if file.endswith(".csv"):
            path = os.path.join(DATA_FOLDER, file)
            try:
                df = pd.read_csv(path)
                df.columns = df.columns.str.strip().str.lower() 
                
                # Combine all text columns into one
                text_columns = df.select_dtypes(include='object').columns
                for _, row in df.iterrows():
                    content = str(row.get("question", ""))  # main searchable text
                    metadata = {
                        "source": file,
                        "answer": str(row.get("answer", "")),
                        "category": str(row.get("category", "")),
                        "keywords": str(row.get("keywords", "")),
                    }
                    all_docs.append(Document(page_content=content, metadata=metadata))
            except Exception as e:
                logger.error(f"Failed to read {file}: {e}")
    return all_docs

def create_text_chunks(documents, chunk_size=500, chunk_overlap=50):
    """Split documents into smaller chunks without LangChain"""
    chunks = []
    for doc in documents:
        text = doc.page_content
        start = 0
        while start < len(text):
            end = start + chunk_size
            chunk_text = text[start:end]
            chunks.append(Document(page_content=chunk_text, metadata=doc.metadata))
            start += chunk_size - chunk_overlap
    return chunks

def process_and_store_csvs():
    try:
        logger.info("Processing CSV files into vector store...")
        documents = load_csv_files()
        if not documents:
            raise CustomException("No CSV documents found in the folder.")

        text_chunks = create_text_chunks(documents)
        save_vector_store(text_chunks)
        logger.info("Vector store created successfully.")

    except Exception as e:
        error_message = CustomException("Failed to process CSV folder", e)
        logger.error(str(error_message))

if __name__ == "__main__":
    process_and_store_csvs()
    documents = load_csv_files()
    print(f"Documents loaded: {len(documents)}")

    text_chunks = create_text_chunks(documents)
    print(f"Chunks created: {len(text_chunks)}")

