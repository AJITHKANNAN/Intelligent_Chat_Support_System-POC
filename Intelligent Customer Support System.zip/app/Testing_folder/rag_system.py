# app/rag_system.py
import os
import faiss
import numpy as np
from dotenv import load_dotenv
from sentence_transformers import SentenceTransformer
from langchain_groq import ChatGroq
from transformers import pipeline
import logging
import evaluate

# -----------------------------
# Logger
# -----------------------------
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# -----------------------------
# Load environment
# -----------------------------
load_dotenv()
from dotenv import load_dotenv
import os

load_dotenv(dotenv_path="E:/Anubavam_task/24Oct/.env")  # full path
print("Loaded GROQ_API_KEY:", os.getenv("GROQ_API_KEY")[:6], "******")


GROQ_API_KEY = os.getenv("GROQ_API_KEY")
if not GROQ_API_KEY:
    raise ValueError("❌ GROQ_API_KEY not found. Check your .env file.")

# -----------------------------
# Load FAISS index & metadata
# -----------------------------
DB_FAISS_PATH = "db/vectorstore_faiss"  # adjust path
index = faiss.read_index(f"{DB_FAISS_PATH}.index")
metadata = np.load(f"{DB_FAISS_PATH}_metadata.npy", allow_pickle=True).tolist()
logger.info("✅ FAISS database loaded successfully.")

# -----------------------------
# Load embedding model
# -----------------------------
embedding_model = SentenceTransformer("all-MiniLM-L6-v2")
logger.info("✅ Embedding model loaded successfully.")

# -----------------------------
# Load Groq LLM
# -----------------------------
llm = ChatGroq(model_name="llama-3.1-8b-instant", groq_api_key=GROQ_API_KEY)
logger.info("✅ Groq LLM loaded.")

# -----------------------------
# Load smaller QA model
# -----------------------------
qa_model = pipeline("question-answering", model="distilbert-base-uncased-distilled-squad")
logger.info("✅ DistilBERT QA model loaded.")

# -----------------------------
# Query classification
# -----------------------------
def classify_query(user_input: str) -> str:
    user_input_lower = user_input.lower()
    if any(w in user_input_lower for w in ["warranty", "guarantee", "protection"]):
        return "warranty"
    elif any(w in user_input_lower for w in ["shipping", "delivery", "tracking"]):
        return "shipping"
    elif any(w in user_input_lower for w in ["return", "refund", "replace"]):
        return "return"
    else:
        return "general"

# -----------------------------
# Retrieve top-k relevant documents from FAISS
# -----------------------------
def retrieve_relevant_docs(query: str, top_k: int = 3):
    query_vector = embedding_model.encode([query], convert_to_numpy=True, normalize_embeddings=True)
    distances, indices = index.search(query_vector, k=top_k)
    return [metadata[i] for i in indices[0] if i < len(metadata)]

# -----------------------------
# Generate LLM response
# -----------------------------
def generate_llm_response(user_input: str, retrieved_docs: list, few_shot: bool = False) -> str:
    retrieved_info = "\n".join([f"- {doc.get('answer') or doc.get('content')}" for doc in retrieved_docs])
    context = ""  # Could pass last chat turns if needed

    # Few-shot examples
    few_shot_examples = ""
    if few_shot:
        few_shot_examples = """
Example 1:
User: How long is the warranty on electronics?
Bot: Electronics come with a 1-year manufacturer's warranty. Extended options are available.

Example 2:
User: Can I return a product if I don't like it?
Bot: Yes, returns are allowed within 30 days of purchase with a receipt.
"""

    prompt = f"""
You are a friendly, human-like customer support assistant.
Respond naturally using simple language, not robotic.

{few_shot_examples}

Relevant Info:
{retrieved_info}

Recent Conversation:
{context}

User: {user_input}
Bot:
"""
    response = llm.invoke(prompt)
    if hasattr(response, "content"):
        return response.content.strip()
    elif isinstance(response, str):
        return response.strip()
    else:
        return str(response).strip()

# -----------------------------
# Small model response
# -----------------------------
def small_model_response(user_input: str, retrieved_docs: list) -> str:
    context_combined = " ".join([doc.get("answer") or doc.get("content") for doc in retrieved_docs])
    result = qa_model(question=user_input, context=context_combined)
    return result["answer"]

# -----------------------------
# Evaluation functions
# -----------------------------


bleu_metric = evaluate.load("bleu")
rouge_metric = evaluate.load("rouge")


def evaluate(predictions: list, references: list):
    # BLEU expects tokenized lists
    predictions_tok = [pred.split() for pred in predictions]
    references_tok = [[ref.split()] for ref in references]
    bleu_score = bleu_metric.compute(predictions=predictions_tok, references=references_tok)
    rouge_score = rouge_metric.compute(predictions=predictions, references=references)
    return {"BLEU": bleu_score, "ROUGE": rouge_score}

# -----------------------------
# Main function
# -----------------------------
def respond(user_input: str, few_shot: bool = False, use_llm: bool = True):
    query_type = classify_query(user_input)
    docs = retrieve_relevant_docs(user_input, top_k=3)

    if use_llm:
        return generate_llm_response(user_input, docs, few_shot=few_shot)
    else:
        return small_model_response(user_input, docs)
