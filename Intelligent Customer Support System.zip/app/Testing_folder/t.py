from groq import Groq

client = Groq(api_key="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")
# print(client.models.list())
import torch

from app.components.llm import groq_load_llm

# llm = groq_load_llm()
# if llm:
#     print("LLM loaded successfully ✅")
# else:
#     print("LLM failed to load ❌")

# from langchain_groq import ChatGroq
# import os
# os.environ["GROQ_API_KEY"] = os.getenv("GROQ_API_KEY")


# llm = ChatGroq(model_name="llama-3.1-8b-instant")
# print(llm.invoke("Hello! Who are you?"))


# import os
# from langchain_groq import ChatGroq
# from dotenv import load_dotenv

# load_dotenv()
# key = os.getenv("GROQ_API_KEY")
# print("Loaded key:", key[:6], "******")


# user_input= input()
# prompt = f"""
# You are a friendly, human-like customer support assistant.
# Respond naturally using simple language, not robotic.


# User: {user_input}
# Bot:
# """


# llm = ChatGroq(model_name="llama-3.1-8b-instant", groq_api_key=key)
# print(llm.invoke(prompt))



# import torch
# from transformers import AutoTokenizer, AutoModelForCausalLM

# PHI3_CACHE_DIR = r"E:\models\huggingface_cache"

# # Load model & tokenizer
# tokenizer = AutoTokenizer.from_pretrained(
#     "microsoft/Phi-3-mini-4k-instruct",
#     trust_remote_code=True,
#     cache_dir=PHI3_CACHE_DIR,
#     local_files_only=True
# )

# device = "cuda" if torch.cuda.is_available() else "cpu"

# model = AutoModelForCausalLM.from_pretrained(
#     "microsoft/Phi-3-mini-4k-instruct",
#     trust_remote_code=True,
#     cache_dir=PHI3_CACHE_DIR,
#     device_map="auto",
#     low_cpu_mem_usage=True,
#     load_in_8bit=True if device=="cuda" else False,
#     local_files_only=True
# )

# model.to(device)

# # Test a simple prompt
# prompt = "You are a friendly assistant. Answer briefly: Who are you?"
# inputs = tokenizer(prompt, return_tensors="pt").to(device)

# outputs = model.generate(
#     **inputs,
#     max_new_tokens=50,
#     temperature=0.7,
#     do_sample=True
# )

# response = tokenizer.decode(outputs[0][inputs["input_ids"].shape[-1]:], skip_special_tokens=True)
# print("Phi-3-Mini Response:", response)


from transformers import AutoModelForCausalLM

model = AutoModelForCausalLM.from_pretrained(
    "microsoft/Phi-3-mini-4k-instruct",
    cache_dir=r"E:\models\huggingface_cache",
    trust_remote_code=True,
    low_cpu_mem_usage=True,
    # device_map="auto",  # auto offloads to GPU if available
    load_in_8bit=True if torch.cuda.is_available() else False
)
